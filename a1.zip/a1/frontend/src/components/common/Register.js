import { useState } from "react";
import axios from "axios";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import * as React from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

const Register = (props) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [roll_no, setRoll_no] = useState("");
  const [user_type, set_user_type] = useState("");
  const [contact_number, set_contact_number] = useState("");
  const [age, setAge] = useState("");
  const [batch_type, set_batch_type] = useState("");
  const [shopName, setShopName] = useState("");
  const [openTime, setOpenTime] = useState("");
  const [closeTime, setCloseTime] = useState("");

  const onChangeName = (event) => {
    setName(event.target.value);
  };

  const onChangeEmail = (event) => {
    setEmail(event.target.value);
  };

  const onChangePassword = (event) => {
    setPassword(event.target.value);
  };

  const onChangeRoll_no = (event) => {
    setRoll_no(event.target.value);
  };

  const onChange_user_type = (event) => {
    set_user_type(event.target.value);
  };

  const onChange_contact_number = (event) => {
    set_contact_number(event.target.value);
  };

  const onChangeAge = (event) => {
    setAge(event.target.value);
  };

  const onChange_batch_type = (event) => {
    set_batch_type(event.target.value);
  };

  const onChangeShopName = (event) => {
    setShopName(event.target.value);
  };

  const onChangeCloseTime = (event) => {
    setCloseTime(event.target.value);
  };
  const onChangeOpenTime = (event) => {
    setOpenTime(event.target.value);
  };

  const resetInputs = () => {
    setName("");
    setEmail("");
    setPassword("");
    setRoll_no("");
    set_user_type("");
    set_contact_number("");
    setAge("");
    set_batch_type("");
    setOpenTime("");
    setShopName("");
    setCloseTime("");
  };

  const onSubmit = (event) => {
    event.preventDefault();

    const newUser = {
      name: name,
      email: email,
      password: password,
      roll_no: roll_no,
      user_type: user_type,
      contact_number: contact_number,
      age: age,
      batch_type: batch_type,
    };

    const newVendor = {
      name: name,
      email: email,
      password: password,
      user_type: user_type,
      contact_number: contact_number,
      shopName: shopName,
      openTime: openTime,
      closeTime: closeTime
    };

    axios
    .post("http://localhost:4000/user/register", newUser)
    .then((response) => {
      alert("Created\t" + response.data.email);
      console.log(response.data);
    });

    axios
    .post("http://localhost:4000/user/register", newVendor)
    .then((response) => {
      alert("Created\t" + response.data.email);
      console.log(response.data);
    });
    
    resetInputs();
  };

  return (
    <Grid container align={"center"} spacing={2}>
      <Grid item xs={12}>
        <FormControl sx={{ m: 1, width: "28ch" }} variant="outlined">
          <InputLabel id="demo-simple-select-label">user_type</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={user_type}
            label="User type"
            onChange={onChange_user_type}
          >
            <MenuItem value={"BUYER"}>Buyer</MenuItem>
            <MenuItem value={"VENDOR"}>Vendor</MenuItem>
          </Select>
        </FormControl>
      </Grid>
      {user_type == "BUYER" && (
        <>
          <Grid item xs={12}>
            <TextField
              label="Name"
              variant="outlined"
              value={name}
              onChange={onChangeName}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Email"
              variant="outlined"
              value={email}
              onChange={onChangeEmail}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Password"
              variant="outlined"
              value={password}
              onChange={onChangePassword}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Roll No"
              variant="outlined"
              value={roll_no}
              onChange={onChangeRoll_no}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Contact number"
              variant="outlined"
              value={contact_number}
              onChange={onChange_contact_number}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="age"
              variant="outlined"
              value={age}
              onChange={onChangeAge}
            />
          </Grid>

          <Grid item xs={12}>
            <FormControl sx={{ m: 1, width: "28ch" }} variant="outlined">
              <InputLabel id="demo-simple-select-label">Batch Name</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={batch_type}
                label="Batch"
                onChange={onChange_batch_type}
              >
                <MenuItem value={"UG1"}>UG1</MenuItem>
                <MenuItem value={"UG2"}>UG2</MenuItem>
                <MenuItem value={"UG3"}>UG3</MenuItem>
                <MenuItem value={"UG4"}>UG4</MenuItem>
                <MenuItem value={"UG5"}>UG5</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </>
      )}
      {user_type == "VENDOR" && (
        <>
          <Grid item xs={12}>
            <TextField
              label="Owner Name"
              variant="outlined"
              value={name}
              onChange={onChangeName}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Email"
              variant="outlined"
              value={email}
              onChange={onChangeEmail}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Password"
              variant="outlined"
              value={password}
              onChange={onChangePassword}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Contact Number"
              variant="outlined"
              value={contact_number}
              onChange={onChange_contact_number}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Shop Name"
              variant="outlined"
              value={shopName}
              onChange={onChangeShopName}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Opening Time"
              variant="outlined"
              value={openTime}
              onChange={onChangeOpenTime}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              label="Closing Time"
              variant="outlined"
              value={closeTime}
              onChange={onChangeCloseTime}
            />
          </Grid>
        </>
      )}
      <Grid item xs={12}>
        <Button variant="contained" onClick={onSubmit}>
          Register
        </Button>
      </Grid>
    </Grid>
  );
};

export default Register;
