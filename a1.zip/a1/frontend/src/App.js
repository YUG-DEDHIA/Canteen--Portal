import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import "./App.css";
import UsersList from "./components/users/UsersList";
import Home from "./components/common/Home";
import Register from "./components/common/Register";
import Navbar from "./components/templates/Navbar";
import Navbar2 from "./components/templates/Navbar2";
import Items from "./components/common/Menu";
import Login from "./components/common/Login";
import logout from "./components/common/Logout";
import Profile from "./components/common/Profile";


function getToken() {
  const tokenString = sessionStorage.getItem('token');
  const userToken = JSON.parse(tokenString);
  return userToken?.token
}

const Layout = () => {
  return (
    <div>
      <Navbar />
      <div className="container">
        <Outlet />
      </div>
    </div>
  );
};
const Layout2 = () => {
  return (
    <div>
      <Navbar2 />
      <div className="container">
        <Outlet />
      </div>
    </div>
  );
};

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="users" element={<UsersList />} />
          <Route path="register" element={<Register />} />
          <Route path="login" element={<Login />} />
          <Route path="/menu" element={<Items />} />
        </Route>


        <Route path="/profile/" element={<Layout2 />}>
          <Route path="/profile/" element={<Profile />} />
          {/* <Route path="/profile/wallet" element={<Wallet />} /> */}
          <Route path="/profile/menu" element={<Items />} />

        </Route>
      </Routes>
    </BrowserRouter>
  );
}


export default App;
