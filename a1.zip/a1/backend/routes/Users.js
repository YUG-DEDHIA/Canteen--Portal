var express = require("express");
var router = express.Router();


// Load User model
const User = require("../models/Users");
const Vendor = require("../models/Vendors")


// GET request 
// Getting all the users
router.get("/", function (req, res) {
    User.find(function (err, users) {
        if (err) {
            console.log(err);
        } else {
            res.json(users);
            console.log(users + "hello");
        }
    })
});


// GET request
// Getting all the vendors
router.get("/", function (req, res) {
    Vendor.find(function (err, users) {
        if (err) {
            console.log(err);
        } else {
            res.json(users);
        }
    })
});

// NOTE: Below functions are just sample to show you API endpoints working, for the assignment you may need to edit them

// POST request 
// Add a user to db
router.post("/register", (req, res) => {

    var user_type = req.body.user_type

    if (user_type == "BUYER") {
        User.findOne({ email: req.body.email })
            .then(user => {
                if (user) {
                    return res.status(200).json({ email: "Email already exists" });
                }
                else {
                    const newUser = new User({
                        name: req.body.name,
                        email: req.body.email,
                        password: req.body.password,
                        roll_no: req.body.roll_no,
                        user_type: req.body.user_type,
                        contact_number: req.body.contact_number,
                        age: req.body.age,
                        batch_type: req.body.batch_type,

                    });
                    newUser.save()
                        .then(user => {
                            res.status(200).json(user);
                        })
                        .catch(err => {
                            res.status(400).send(err);
                        });
                }
            });
    }
    else if (user_type == "VENDOR") {
        Vendor.findOne({ email: req.body.email })
            .then(vendor => {
                if (vendor) {
                    return res.status(200).json({ email: "Email already exists" });
                }
                else {
                    const newVendor = new Vendor({
                        name: req.body.name,
                        email: req.body.email,
                        password: req.body.password,
                        user_type: req.body.user_type,
                        contact_number: req.body.contact_number,
                        shopName: req.body.shopName,
                        openTime: req.body.openTime,
                        closeTime: req.body.closeTime
                    });
                    newVendor.save()
                        .then(vendor => {
                            res.status(200).json(vendor);
                        })
                        .catch(err => {
                            res.status(400).send(err);
                        });
                }
            });
    }
});

// POST request 
// Login
router.post("/login", (req, res) => {
    const email = req.body.email;
    User.findOne({ email }).then(user => {
        if (!user) {
            Vendor.findOne({ email }).then(vendor => {
                if (!vendor) {
                    res.send(null);
                }
                else {
                    if (vendor.password === req.body.password) {
                        res.send(vendor);
                        return vendor;
                    }
                    else {
                        res.send(null);
                    }
                }
            })
        }
        else {
            if (user.password === req.body.password) {
                res.send(user);
                return user;
            }
            else {
                res.send(null);
            }
        }
    });
});

router.post("/profile", (req, res) => {

    const email = req.body.email;

    User.findOne({ email })
        .then(user => {
            if (user != null) {
                return res.json(user)
            }
            if (Vendor == null) {
                Vendor.findOne({ email })
                    .then(user => {
                        if
                })
            }
            else {
                res.json(null)
            }

        }
        )
        .catch(err => { console.log(err); })
});


router.post("/update/:id", (req, res) => {

    User.findById(req.params.id)
        .then(user => {
            user.name = req.body.name;
            user.email = req.body.email;
            user.password = req.body.password;
            user.contact_number = req.body.contact_number;
            user.age = req.body.age;
            user.batch_type = req.body.batch_type;
            user.user_type = req.body.user_type;
            // user.wallet = req.body.wallet;

            user.save()
                .then(user => {
                    res.json(user);
                    console.log("updated!");
                })
                .catch(err => res.status(400).json("Error: " + err))
        })
        .catch(err => res.status(400).json("Error: " + err))
})
module.exports = router;