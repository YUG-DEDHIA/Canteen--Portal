const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Create Schema
const VendorsSchema = new Schema({
    name: {
        type: String,
        //required: true
    },
    email: {
        type: String,
        //required: true
    },
    password: {
        type: String,
        //required: true
    },
    openTime: {
        type: String,
        // required: true
    },
    user_type: {
        type: String,
        // required: true
    },
    contact_number: {
        type: String,
        //required: true
    },
    closeTime: {
        type: Number,
        // required: true
    },
    shopName: {
        type: String,
        // required: true
    },
});

module.exports = User = mongoose.model("Vendors", VendorsSchema);